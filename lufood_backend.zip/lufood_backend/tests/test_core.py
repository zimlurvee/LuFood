"""Run with:  pytest   (needs pandas, numpy, scikit-learn, joblib, pytest)"""
import tempfile
from pathlib import Path

from app import service
from app.core import features_from_readings
from app.db import Store
from app.ml import Predictor, train

_cache = {}


def predictor():
    if "p" not in _cache:
        path = Path(tempfile.mkdtemp()) / "m.joblib"
        train(n=1500, path=path)
        _cache["p"] = Predictor.load(path)
    return _cache["p"]


def test_same_latest_temp_different_history():
    short = features_from_readings("chicken", 3, [(0, 4), (170 / 60, 25)])
    long_ = features_from_readings("chicken", 3, [(0, 25)])
    assert short["latest_temp"] == long_["latest_temp"] == 25
    assert round(short["danger_hours"], 2) == 0.17 and long_["danger_hours"] == 3.0


def test_invalid_input_rejected():
    for bad in [("seafood", 3, [(0, 4)]), ("rice", 0, [(0, 4)]), ("rice", 3, []), ("rice", 3, [(4, 20)])]:
        try:
            features_from_readings(*bad)
        except ValueError:
            continue
        raise AssertionError(f"accepted bad input {bad}")


def test_risk_rises_with_exposure():
    p = predictor()
    cold = service.assess(p, "chicken", 6, [(0, 3), (3, 3)])
    warm = service.assess(p, "chicken", 6, [(0, 30), (3, 31)])
    assert cold["label"] == "low" and cold["probabilities"]["high"] < warm["probabilities"]["high"]
    assert warm["label"] in ("moderate", "high")


def test_explanation_adds_up():
    """Shapley efficiency: contributions sum to risk(food) - risk(average food)."""
    import numpy as np
    import pandas as pd
    p = predictor()
    feats = features_from_readings("chicken", 7, [(0, 30), (3, 31)])
    x = pd.DataFrame([feats])[p.features]
    phi, _ = p.explain(x)
    bg = pd.DataFrame([p.background])[p.features]
    gap = p.risk_score(p.model.predict_proba(x))[0] - p.risk_score(p.model.predict_proba(bg))[0]
    assert abs(sum(phi.values()) - gap) < 1e-6
    out = service.assess(p, "chicken", 7, [(0, 30), (3, 31)])
    assert abs(sum(out["probabilities"].values()) - 1) < 1e-3
    assert any(c["value"] > 0 for c in out["contributions"][:3])      # something pushes risk up


def test_store_roundtrip():
    store = Store(f"sqlite:///{Path(tempfile.mkdtemp()) / 't.db'}")
    out = service.assess(predictor(), "rice", 3, [(0, 28)])
    aid = store.save_assessment("user-12345", "rice", 3, [{"hour": 0, "temp_c": 28}], out)
    rows = store.list_assessments("user-12345")
    assert rows[0]["id"] == aid and rows[0]["label"] == out["label"] and store.list_assessments("other-user") == []
    store.upsert_profile("user-12345", "Zim", ["Peanuts"], "some")
    store.upsert_profile("user-12345", "Zim A", [], "often")
    assert store.get_profile("user-12345")["name"] == "Zim A"
    store.clear_assessments("user-12345")
    assert store.list_assessments("user-12345") == []
