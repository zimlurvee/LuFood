"""Token checks. Run with:  pytest   (needs pyjwt[crypto])"""
import os
import time
from contextlib import contextmanager

import pytest

jwt = pytest.importorskip("jwt")
from app import auth  # noqa: E402

SECRET = "s" * 40
URL = "https://abc.supabase.co"


@contextmanager
def env(**kw):
    keys = ["SUPABASE_URL", "SUPABASE_JWT_SECRET", "LUFOOD_DEV_AUTH"]
    old = {k: os.environ.pop(k, None) for k in keys}
    os.environ.update(kw)
    try:
        yield
    finally:
        for k in keys:
            os.environ.pop(k, None)
        os.environ.update({k: v for k, v in old.items() if v is not None})


def claims(**over):
    return {"sub": "user-abc", "aud": "authenticated", "exp": int(time.time()) + 300, "iss": f"{URL}/auth/v1", **over}


def rejects(fn):
    try:
        fn()
    except auth.AuthError:
        return True
    return False


def test_hs256_accepts_valid_and_rejects_bad():
    with env(SUPABASE_JWT_SECRET=SECRET):
        good = jwt.encode(claims(), SECRET, algorithm="HS256")
        assert auth.get_user_id(f"Bearer {good}") == "user-abc"
        assert rejects(lambda: auth.get_user_id("Bearer " + jwt.encode(claims(), "x" * 40, algorithm="HS256")))
        assert rejects(lambda: auth.get_user_id("Bearer " + jwt.encode(claims(exp=int(time.time()) - 10), SECRET, algorithm="HS256")))
        assert rejects(lambda: auth.get_user_id("Bearer " + jwt.encode(claims(aud="anon"), SECRET, algorithm="HS256")))
        assert rejects(lambda: auth.get_user_id("Bearer " + jwt.encode({"aud": "authenticated", "exp": int(time.time()) + 60}, SECRET, algorithm="HS256")))
        assert rejects(lambda: auth.get_user_id("Basic abc"))


def test_es256_with_jwks_key():
    from cryptography.hazmat.primitives.asymmetric import ec
    priv = ec.generate_private_key(ec.SECP256R1())
    real = auth._signing_key
    auth._signing_key = lambda token, url: priv.public_key()          # stands in for the JWKS lookup
    try:
        with env(SUPABASE_URL=URL):
            good = jwt.encode(claims(), priv, algorithm="ES256", headers={"kid": "k1"})
            assert auth.get_user_id(f"Bearer {good}") == "user-abc"
            assert rejects(lambda: auth.get_user_id("Bearer " + jwt.encode(claims(iss="https://evil.example/auth/v1"), priv, algorithm="ES256")))
            other = ec.generate_private_key(ec.SECP256R1())
            assert rejects(lambda: auth.get_user_id("Bearer " + jwt.encode(claims(), other, algorithm="ES256")))
    finally:
        auth._signing_key = real


def test_dev_header_rules():
    with env():                                                    # nothing configured: dev header works
        assert auth.get_user_id(None, "device-12345") == "device-12345" and auth.get_user_id() is None
        assert rejects(lambda: auth.get_user_id(None, "short"))
    with env(SUPABASE_JWT_SECRET=SECRET):                          # configured: dev header ignored
        assert auth.get_user_id(None, "device-12345") is None
    with env(SUPABASE_JWT_SECRET=SECRET, LUFOOD_DEV_AUTH="1"):
        assert auth.get_user_id(None, "device-12345") == "device-12345"


def test_hs256_without_secret_asks_supabase():
    import io
    import json as _json
    import urllib.request as ur
    calls = []

    class Resp(io.BytesIO):
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def fake(req, timeout=5):
        calls.append(req.headers)
        if req.headers.get("Authorization") == "Bearer good-token-from-supabase":
            return Resp(_json.dumps({"id": "user-from-server"}).encode())
        raise OSError("401")

    real = ur.urlopen
    ur.urlopen = fake
    try:
        with env(SUPABASE_URL=URL, SUPABASE_ANON_KEY="sb_publishable_x"):
            # an HS256-signed token (we do not hold the secret, so the server has to judge it)
            tok = jwt.encode(claims(), "whatever" * 6, algorithm="HS256")
            assert rejects(lambda: auth.get_user_id(f"Bearer {tok}"))                    # server says no -> rejected
            auth._seen["good-token-from-supabase"] = None
            auth._seen.clear()
            real_header = jwt.get_unverified_header
            jwt.get_unverified_header = lambda t: {"alg": "HS256"}
            try:
                assert auth.get_user_id("Bearer good-token-from-supabase") == "user-from-server"
                n = len(calls)
                assert auth.get_user_id("Bearer good-token-from-supabase") == "user-from-server" and len(calls) == n   # cached
            finally:
                jwt.get_unverified_header = real_header
        with env(SUPABASE_URL=URL):                                                      # no anon key configured
            assert rejects(lambda: auth.get_user_id("Bearer " + jwt.encode(claims(), "x" * 40, algorithm="HS256")))
    finally:
        ur.urlopen = real
