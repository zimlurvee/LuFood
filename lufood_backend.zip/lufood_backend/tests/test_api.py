"""API tests. Run with:  pytest   (needs fastapi, httpx; skipped if they are missing)"""
import os
import tempfile
from pathlib import Path

import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")
tmp = Path(tempfile.mkdtemp())
os.environ["LUFOOD_MODEL"] = str(tmp / "m.joblib")
os.environ["DATABASE_URL"] = f"sqlite:///{tmp / 't.db'}"

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from app.ml import train  # noqa: E402

train(n=1500, path=tmp / "m.joblib")
BODY = {"food": "chicken", "total_hours": 3, "readings": [{"hour": 0, "temp_c": 28}, {"hour": 1, "temp_c": 31}]}
H = {"X-User-Id": "user-12345"}


def test_flow():
    with TestClient(app) as c:
        assert c.get("/api/health").json()["status"] == "ok"
        r = c.post("/api/assess", json=BODY, headers=H).json()
        assert r["label"] in ("low", "moderate", "high") and "id" in r and r["contributions"]
        assert "id" not in c.post("/api/assess", json=BODY).json()          # anonymous: not saved
        assert len(c.get("/api/assessments", headers=H).json()) == 1
        assert c.get("/api/assessments").status_code == 401
        assert c.put("/api/profile", json={"name": "Zim", "allergies": ["Eggs"], "cooking": "some"}, headers=H).status_code == 200
        assert c.get("/api/profile", headers=H).json()["name"] == "Zim"
        assert c.delete("/api/assessments", headers=H).status_code == 204


def test_validation():
    with TestClient(app) as c:
        assert c.post("/api/assess", json={**BODY, "food": "seafood"}).status_code == 422
        assert c.post("/api/assess", json={**BODY, "readings": [{"hour": 9, "temp_c": 20}]}).status_code == 422
