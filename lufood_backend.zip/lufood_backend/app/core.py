"""Layer 2 - Data processing (Python + Pandas + NumPy).
Turns a raw temperature history into the features the model uses."""
import numpy as np
import pandas as pd

DANGER_LOW, DANGER_HIGH = 5.0, 60.0          # the 5-60 C "danger zone"
SAFE_HOURS, LIMIT_HOURS = 2.0, 4.0           # 2h / 4h rule (baseline only)
FOODS = {"chicken": "cooked chicken", "rice": "cooked rice"}   # seafood: needs its own hazard + data first
LABELS = ["low", "moderate", "high"]
FEATURES = ["latest_temp", "mean_temp", "max_temp", "temp_range", "total_hours",
            "danger_hours", "food_cooked chicken", "food_cooked rice"]

REC = {
    "low": "Time in the danger zone is short. Refrigerate promptly at 5 °C or below and finish it within a day or two.",
    "moderate": "This food has spent a notable time in the danger zone. Eat it right away, or discard it if you're unsure. Don't put it back in the fridge to eat later.",
    "high": "Long exposure to unsafe temperatures. Discard it. Reheating will not remove toxins that some bacteria, such as B. cereus, can produce.",
}
FOOD_REC = {"chicken": " Keep cooked chicken at 60 °C or above, or at 5 °C or below.",
            "rice": " Cool cooked rice quickly and refrigerate it within an hour or two."}
DISCLAIMER = ("Decision-support estimate only, not a guarantee that food is safe. It cannot detect pathogens, "
              "toxins, allergens or chemicals. The model is trained on simulated data with placeholder growth "
              "parameters and has not been validated against real microbiological data.")


def features_from_readings(food, total_hours, readings):
    """readings: list of (hour, temp_c). Each reading is assumed to hold until the next one;
    the last reading holds until total_hours (the assessment time)."""
    if food not in FOODS:
        raise ValueError(f"Unsupported food '{food}'. Supported: {', '.join(FOODS)}.")
    if not total_hours or total_hours <= 0:
        raise ValueError("total_hours must be above 0.")
    df = pd.DataFrame(list(readings), columns=["hour", "temp"], dtype=float)
    if df.empty:
        raise ValueError("At least one temperature reading is required.")
    if df["hour"].min() < 0 or df["hour"].max() > total_hours:
        raise ValueError("Readings must be between 0 and total_hours.")
    df = df.sort_values("hour", kind="stable").reset_index(drop=True)
    df["held"] = np.diff(df["hour"].to_numpy(), append=total_hours)      # hours each reading holds
    in_zone = (df["temp"] > DANGER_LOW) & (df["temp"] < DANGER_HIGH)
    t = df["temp"]
    return {
        "latest_temp": float(t.iloc[-1]), "mean_temp": float(t.mean()),
        "max_temp": float(t.max()), "temp_range": float(t.max() - t.min()),
        "total_hours": float(total_hours), "danger_hours": float(df.loc[in_zone, "held"].sum()),
        "food_cooked chicken": float(food == "chicken"), "food_cooked rice": float(food == "rice"),
    }


def rule_label(danger_hours):
    return "low" if danger_hours <= SAFE_HOURS else "moderate" if danger_hours <= LIMIT_HOURS else "high"


def recommendation(label, food):
    return REC[label] + FOOD_REC[food]
