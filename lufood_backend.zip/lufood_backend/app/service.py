"""Business logic, independent of the web framework (so it is easy to test)."""
from .core import DISCLAIMER, FOODS, features_from_readings, recommendation, rule_label
from .simulate import PARAMS, growth_label, log_increase


def assess(predictor, food, total_hours, readings):
    """readings: list of (hour, temp_c). Raises ValueError on invalid input."""
    readings = [(float(h), float(t)) for h, t in readings]
    feats = features_from_readings(food, total_hours, readings)
    out = predictor.predict(feats)
    params = PARAMS[FOODS[food]]
    inc = log_increase(readings, total_hours, params)
    out.update({
        "features": feats,
        "recommendation": recommendation(out["label"], food),
        "reference": {"organism": params["organism"], "danger_hours": round(feats["danger_hours"], 2),
                      "rule_label": rule_label(feats["danger_hours"]),
                      "growth_log10_increase": round(inc, 2), "growth_label": growth_label(inc)},
        "model": predictor.info(),
        "disclaimer": DISCLAIMER,
    })
    return out
