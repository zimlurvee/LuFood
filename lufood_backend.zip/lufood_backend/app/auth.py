"""Authentication: verifies Supabase Auth access tokens (JWTs).  pip install "pyjwt[crypto]"

- Supabase configured (SUPABASE_URL and/or SUPABASE_JWT_SECRET): requests need `Authorization: Bearer <token>`.
    * asymmetric signing keys (ES256/RS256): public keys are fetched from <SUPABASE_URL>/auth/v1/.well-known/jwks.json
    * legacy HS256 projects: set SUPABASE_JWT_SECRET, or leave it unset and set SUPABASE_URL + SUPABASE_ANON_KEY
      (the token is then validated by asking Supabase Auth itself, cached for 60 seconds)
  Signature, expiry, audience ("authenticated") and subject are always checked.
- Nothing configured (local dev): the placeholder `X-User-Id` header identifies a device.
  Set LUFOOD_DEV_AUTH=1 to also allow that header when Supabase is configured (not for production)."""
import json
import os
import time
import urllib.request


class AuthError(Exception):
    pass


def _cfg():
    return {"url": os.getenv("SUPABASE_URL", "").rstrip("/"), "secret": os.getenv("SUPABASE_JWT_SECRET", ""),
            "dev": os.getenv("LUFOOD_DEV_AUTH") == "1",
            "anon": os.getenv("SUPABASE_ANON_KEY", "")}


def supabase_enabled():
    c = _cfg()
    return bool(c["url"] or c["secret"])


_clients = {}


def _signing_key(token, url):
    import jwt
    if url not in _clients:
        _clients[url] = jwt.PyJWKClient(f"{url}/auth/v1/.well-known/jwks.json", cache_keys=True)
    return _clients[url].get_signing_key_from_jwt(token).key


_seen = {}


def _verify_with_auth_server(token, c):
    """HS256 token but no shared secret: ask Supabase Auth who this is (valid, unexpired tokens only)."""
    if not (c["url"] and c["anon"]):
        raise AuthError("Set SUPABASE_JWT_SECRET, or SUPABASE_URL and SUPABASE_ANON_KEY, to verify these tokens.")
    hit = _seen.get(token)
    if hit and hit[1] > time.time():
        return hit[0]
    req = urllib.request.Request(f"{c['url']}/auth/v1/user", headers={"Authorization": f"Bearer {token}", "apikey": c["anon"]})
    try:
        with urllib.request.urlopen(req, timeout=5) as r:
            uid = json.load(r).get("id")
    except Exception as e:
        raise AuthError("Invalid or expired token.") from e
    if not uid:
        raise AuthError("Invalid or expired token.")
    if len(_seen) > 1000:
        _seen.clear()
    _seen[token] = (uid, time.time() + 60)
    return uid


def verify_token(token):
    """Returns the user id (the `sub` claim) or raises AuthError."""
    import jwt
    c = _cfg()
    try:
        alg = jwt.get_unverified_header(token).get("alg")
        if alg == "HS256":
            if not c["secret"]:
                return _verify_with_auth_server(token, c)
            key = c["secret"]
        elif alg in ("ES256", "RS256"):
            if not c["url"]:
                raise AuthError("This server has no SUPABASE_URL for asymmetric tokens.")
            key = _signing_key(token, c["url"])
        else:
            raise AuthError("Unsupported token algorithm.")
        extra = {"issuer": f"{c['url']}/auth/v1"} if c["url"] else {}
        claims = jwt.decode(token, key, algorithms=[alg], audience="authenticated",
                            options={"require": ["exp", "sub"]}, **extra)
    except AuthError:
        raise
    except Exception as e:
        raise AuthError("Invalid or expired token.") from e
    return claims["sub"]


def get_user_id(authorization=None, x_user_id=None):
    """User id for this request, or None if anonymous. Raises AuthError on bad credentials."""
    if authorization:
        scheme, _, token = authorization.partition(" ")
        if scheme.lower() != "bearer" or not token:
            raise AuthError("Use 'Authorization: Bearer <token>'.")
        if not supabase_enabled():
            raise AuthError("Token authentication is not configured on this server.")
        return verify_token(token)
    if x_user_id and (not supabase_enabled() or _cfg()["dev"]):
        if len(x_user_id) < 8:
            raise AuthError("X-User-Id must be at least 8 characters.")
        return x_user_id
    return None
