"""Training data: simulated storage histories labelled by a predictive-microbiology growth model.

!! PARAMS and the label thresholds are PLACEHOLDERS so the pipeline runs end to end.
!! Replace them with values fitted from ComBase / published studies (see ../lufood_growth.py
!! fit_secondary_model) and validate on real, held-out growth curves before trusting any result."""
import numpy as np
import pandas as pd

from .core import FOODS, features_from_readings

PARAMS = {   # Ratkowsky square-root model: sqrt(mu) = b * (T - Tmin);  h0 = lag "work to be done"
    "cooked rice":    {"organism": "B. cereus",  "b": 0.024, "tmin": 7.0, "topt": 37.0, "h0": 0.5, "max_increase": 6.0},
    "cooked chicken": {"organism": "Salmonella", "b": 0.024, "tmin": 5.0, "topt": 37.0, "h0": 0.5, "max_increase": 6.0},
}
LOW_BELOW, HIGH_FROM = 1.0, 2.0   # log10-increase cut-offs (PLACEHOLDERS)


def growth_rate(temp, p):
    if temp <= p["tmin"]:
        return 0.0
    return (p["b"] * (min(temp, p["topt"]) - p["tmin"])) ** 2          # log10 CFU / hour


def log_increase(readings, total_hours, p):
    """Predicted log10 growth over the whole history (step-hold between readings)."""
    r = sorted(readings)
    exposure = 0.0
    for i, (hour, temp) in enumerate(r):
        nxt = r[i + 1][0] if i + 1 < len(r) else total_hours
        exposure += growth_rate(temp, p) * (nxt - hour)
    return min(max(exposure - p["h0"], 0.0), p["max_increase"])


def growth_label(increase):
    return "low" if increase < LOW_BELOW else "moderate" if increase < HIGH_FROM else "high"


def simulate_readings(rng):
    """One fake storage history: a reading every 30 minutes for 1-8 hours."""
    end = float(rng.uniform(1, 8))
    scenario = rng.choice(["fridge", "room", "cooling", "out_then_fridge"])
    fridge_at = rng.uniform(0.2, 0.8) * end
    readings = []
    for h in np.arange(0, end, 0.5):
        if scenario == "fridge":
            t = rng.normal(3, 1)
        elif scenario == "room":
            t = rng.normal(29, 2)
        elif scenario == "cooling":
            t = max(28, 70 - 24 * h) + rng.normal(0, 1)
        else:
            t = rng.normal(29, 2) if h < fridge_at else rng.normal(3, 1)
        readings.append((float(h), round(float(t), 1)))
    return readings, end


def build_dataset(n=6000, seed=42):
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(n):
        food = str(rng.choice(list(FOODS)))
        readings, end = simulate_readings(rng)
        feats = features_from_readings(food, end, readings)
        feats["log_increase"] = log_increase(readings, end, PARAMS[FOODS[food]])
        feats["label"] = growth_label(feats["log_increase"])
        rows.append(feats)
    return pd.DataFrame(rows)
