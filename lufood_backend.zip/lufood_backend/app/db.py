"""Layer 4 - Results and database.
SQLite for local development; PostgreSQL / Supabase when DATABASE_URL is a postgres URL.
One code path for both: plain SQL, UUID ids and ISO timestamps generated in Python."""
import json
import os
import sqlite3
import uuid
from contextlib import closing
from datetime import datetime, timezone

SCHEMA = [
    """CREATE TABLE IF NOT EXISTS profiles (
        user_id TEXT PRIMARY KEY, name TEXT NOT NULL, allergies TEXT NOT NULL,
        cooking TEXT NOT NULL, updated_at TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS assessments (
        id TEXT PRIMARY KEY, user_id TEXT NOT NULL, food TEXT NOT NULL, total_hours REAL NOT NULL,
        readings TEXT NOT NULL, label TEXT NOT NULL, result TEXT NOT NULL, created_at TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS idx_assessments_user ON assessments (user_id, created_at)",
]
now = lambda: datetime.now(timezone.utc).isoformat()


class Store:
    def __init__(self, url=None):
        url = url or os.getenv("DATABASE_URL", "sqlite:///lufood.db")
        self.pg = url.startswith(("postgres://", "postgresql://"))
        if self.pg:
            import psycopg                                   # pip install "psycopg[binary]"
            self._connect = lambda: psycopg.connect(url)
        else:
            path = url.removeprefix("sqlite:///")
            self._connect = lambda: sqlite3.connect(path)
        for stmt in SCHEMA:
            self._run(stmt)

    def _run(self, sql, params=(), fetch=False):
        if self.pg:
            sql = sql.replace("?", "%s")
        with closing(self._connect()) as con:
            cur = con.cursor()
            cur.execute(sql, params)
            rows = None
            if fetch:
                cols = [c[0] for c in cur.description]
                rows = [dict(zip(cols, r)) for r in cur.fetchall()]
            con.commit()
            return rows

    # ---- assessments ----
    def save_assessment(self, user_id, food, total_hours, readings, result):
        aid = str(uuid.uuid4())
        self._run("INSERT INTO assessments (id, user_id, food, total_hours, readings, label, result, created_at) "
                  "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                  (aid, user_id, food, total_hours, json.dumps(readings), result["label"], json.dumps(result), now()))
        return aid

    def list_assessments(self, user_id, limit=20):
        rows = self._run("SELECT id, food, total_hours, readings, label, result, created_at FROM assessments "
                         "WHERE user_id = ? ORDER BY created_at DESC LIMIT ?", (user_id, limit), fetch=True)
        for r in rows:
            r["readings"], r["result"] = json.loads(r["readings"]), json.loads(r["result"])
        return rows

    def clear_assessments(self, user_id):
        self._run("DELETE FROM assessments WHERE user_id = ?", (user_id,))

    # ---- profile ----
    def get_profile(self, user_id):
        rows = self._run("SELECT name, allergies, cooking, updated_at FROM profiles WHERE user_id = ?", (user_id,), fetch=True)
        if not rows:
            return None
        rows[0]["allergies"] = json.loads(rows[0]["allergies"])
        return rows[0]

    def upsert_profile(self, user_id, name, allergies, cooking):
        self._run("INSERT INTO profiles (user_id, name, allergies, cooking, updated_at) VALUES (?, ?, ?, ?, ?) "
                  "ON CONFLICT (user_id) DO UPDATE SET name = excluded.name, allergies = excluded.allergies, "
                  "cooking = excluded.cooking, updated_at = excluded.updated_at",
                  (user_id, name, json.dumps(allergies), cooking, now()))
