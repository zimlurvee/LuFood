"""LuFood API (FastAPI): connects the interface, data processing, prediction engine and database.
Run:  uvicorn app.main:app --reload      then open http://localhost:8000"""
import json
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import service
from .auth import AuthError, get_user_id
from .db import Store
from .ml import Predictor

state = {}
FRONT_DIR = Path(__file__).resolve().parent.parent / "frontend"
FRONTEND = FRONT_DIR / "index.html"


@asynccontextmanager
async def lifespan(app):
    state["predictor"] = Predictor.load()
    state["store"] = Store()
    yield


app = FastAPI(title="LuFood API", version="0.1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_methods=["*"], allow_headers=["*"],
                   allow_origins=os.getenv("LUFOOD_ORIGINS", "http://localhost:8000").split(","))


class Reading(BaseModel):
    hour: float = Field(ge=0, le=168)
    temp_c: float = Field(ge=-40, le=150)


class AssessIn(BaseModel):
    food: str = Field(pattern="^(chicken|rice)$")
    total_hours: float = Field(gt=0, le=168)
    readings: list[Reading] = Field(min_length=1, max_length=50)


class ProfileIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    allergies: list[str] = Field(default_factory=list, max_length=20)
    cooking: str = Field(pattern="^(rare|some|often|daily)$")


def user(authorization, x_user_id, required=True):
    """Resolve the caller (Supabase token, or the dev header when nothing is configured)."""
    try:
        u = get_user_id(authorization, x_user_id)
    except AuthError as e:
        raise HTTPException(401, str(e))
    if required and not u:
        raise HTTPException(401, "Sign in required.")
    return u


@app.get("/api/health")
def health():
    return {"status": "ok", "model": state["predictor"].info()}


@app.post("/api/assess")
def assess(body: AssessIn, authorization: str | None = Header(default=None), x_user_id: str | None = Header(default=None)):
    try:
        out = service.assess(state["predictor"], body.food, body.total_hours,
                             [(r.hour, r.temp_c) for r in body.readings])
    except ValueError as e:
        raise HTTPException(422, str(e))
    u = user(authorization, x_user_id, required=False)
    if u:                                                      # save to history when a user is identified
        out["id"] = state["store"].save_assessment(u, body.food, body.total_hours,
                                                   [r.model_dump() for r in body.readings], out)
    return out


@app.get("/api/assessments")
def history(limit: int = 20, authorization: str | None = Header(default=None), x_user_id: str | None = Header(default=None)):
    return state["store"].list_assessments(user(authorization, x_user_id), max(1, min(limit, 100)))


@app.delete("/api/assessments", status_code=204)
def clear_history(authorization: str | None = Header(default=None), x_user_id: str | None = Header(default=None)):
    state["store"].clear_assessments(user(authorization, x_user_id))


@app.get("/api/profile")
def get_profile(authorization: str | None = Header(default=None), x_user_id: str | None = Header(default=None)):
    p = state["store"].get_profile(user(authorization, x_user_id))
    if not p:
        raise HTTPException(404, "No profile yet.")
    return p


@app.put("/api/profile")
def put_profile(body: ProfileIn, authorization: str | None = Header(default=None), x_user_id: str | None = Header(default=None)):
    state["store"].upsert_profile(user(authorization, x_user_id), body.name.strip(), body.allergies, body.cooking)
    return {"ok": True}


def head_tags():
    tags = ['<link rel="manifest" href="/manifest.webmanifest">', '<meta name="theme-color" content="#f9a8d4">',
            '<meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes">',
            '<meta name="apple-mobile-web-app-title" content="LuFood">',
            '<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">',
            '<script>window.LUFOOD_API=""</script>']          # same-origin: use this API, not the in-browser model
    url, key = os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_ANON_KEY")   # the publishable (anon) key is meant for browsers
    if url and key:
        cfg = json.dumps({"url": url, "key": key}).replace("<", "\\u003c")
        tags += [f"<script>window.LUFOOD_SUPABASE={cfg}</script>",
                 '<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js"></script>']
    return "".join(tags)


@app.get("/", response_class=HTMLResponse)
def home():
    if not FRONTEND.exists():
        raise HTTPException(404, "frontend/index.html not found.")
    html = FRONTEND.read_text(encoding="utf-8").replace("<head>", "<head>" + head_tags(), 1)
    sw = '<script>if("serviceWorker" in navigator)addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}))</script>'
    return html.replace("</body>", sw + "</body>", 1)


@app.get("/manifest.webmanifest")
def manifest():
    return FileResponse(FRONT_DIR / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js")
def service_worker():
    return FileResponse(FRONT_DIR / "sw.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


app.mount("/icons", StaticFiles(directory=FRONT_DIR / "icons"), name="icons")
