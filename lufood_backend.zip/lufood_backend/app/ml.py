"""Layer 3 - AI prediction engine (Logistic Regression / Random Forest / XGBoost) + explanations."""
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .core import FEATURES, LABELS
from .simulate import build_dataset

MODEL_PATH = Path(os.getenv("LUFOOD_MODEL", "models/model.joblib"))
HIGH = LABELS.index("high")


def candidates():
    models = {
        "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000)),
        "Random Forest": RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1),
    }
    try:
        from xgboost import XGBClassifier
        models["XGBoost"] = XGBClassifier(n_estimators=300, max_depth=4, learning_rate=0.1, random_state=42)
    except ImportError:
        print("(XGBoost not installed - skipping it. pip install xgboost)")
    return models


def train(n=6000, seed=42, path=MODEL_PATH):
    """Train every candidate, keep the best by macro-F1 (recall on 'high' is reported too)."""
    df = build_dataset(n, seed)
    y = df["label"].map({l: i for i, l in enumerate(LABELS)})
    Xtr, Xte, ytr, yte = train_test_split(df[FEATURES], y, test_size=0.2, stratify=y, random_state=seed)
    metrics, best = {}, None
    for name, model in candidates().items():
        model.fit(Xtr, ytr)
        pred = model.predict(Xte)
        metrics[name] = {"accuracy": round(accuracy_score(yte, pred), 4),
                         "f1_macro": round(f1_score(yte, pred, average="macro"), 4),
                         "recall_high": round(recall_score(yte, pred, labels=[HIGH], average="macro"), 4)}
        if best is None or metrics[name]["f1_macro"] > metrics[best[0]]["f1_macro"]:
            best = (name, model)
    bundle = {"name": best[0], "model": best[1], "features": FEATURES, "background": Xtr.mean().to_dict(),
              "metrics": metrics, "n_train": len(Xtr), "trained_at": datetime.now(timezone.utc).isoformat(),
              "note": "Trained on simulated data with placeholder growth parameters."}
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, path)
    path.with_suffix(".json").write_text(json.dumps({k: v for k, v in bundle.items() if k not in ("model", "background")}, indent=2))
    return bundle


class Predictor:
    def __init__(self, bundle):
        self.name, self.model, self.features = bundle["name"], bundle["model"], bundle["features"]
        self.background, self.metrics = bundle["background"], bundle["metrics"]

    @classmethod
    def load(cls, path=MODEL_PATH):
        if not Path(path).exists():
            raise FileNotFoundError(f"No model at {path}. Run `python train.py` first.")
        return cls(joblib.load(path))

    def info(self):
        return {"name": self.name, "metrics": self.metrics.get(self.name)}

    def predict(self, feats):
        x = pd.DataFrame([feats])[self.features]
        proba = self.model.predict_proba(x)[0]
        contrib, method = self.explain(x)
        ranked = sorted(contrib.items(), key=lambda kv: -abs(kv[1]))
        return {"label": LABELS[int(np.argmax(proba))],
                "probabilities": {l: round(float(p), 4) for l, p in zip(LABELS, proba)},
                "contributions": [{"feature": k, "value": round(v, 4)} for k, v in ranked],
                "explanation_method": method}

    @staticmethod
    def risk_score(proba):
        """Smooth 0-2 risk level: P(moderate) + 2 * P(high). Used for explanations."""
        return proba[:, 1] + 2 * proba[:, 2]

    def explain(self, x):
        """Positive value = pushes the risk level up vs an average food. SHAP when installed
        (tree models), otherwise sampled Shapley values; both explain the same risk score."""
        try:
            import shap
            sv = shap.TreeExplainer(self.model).shap_values(x)
            if isinstance(sv, list):
                arr = sv[1][0] + 2 * sv[2][0]
            else:
                arr = sv[0][:, 1] + 2 * sv[0][:, 2]
            return {f: float(v) for f, v in zip(self.features, arr)}, "shap"
        except Exception:
            return self._sampling_shapley(x), "sampling-shapley"

    def _sampling_shapley(self, x, n_perm=24):
        """Average marginal contribution of each feature, switching features from the average
        value (training mean) to this food's value in random orders. Contributions add up exactly
        to risk_score(food) - risk_score(average)."""
        rng = np.random.default_rng(0)
        xv = x.iloc[0].to_numpy(float)
        bg = np.array([self.background[f] for f in self.features])
        d, rows, orders = len(xv), [], []
        for _ in range(n_perm):
            order = rng.permutation(d)
            cur = bg.copy()
            rows.append(cur.copy())
            for j in order:
                cur[j] = xv[j]
                rows.append(cur.copy())
            orders.append(order)
        score = self.risk_score(self.model.predict_proba(pd.DataFrame(rows, columns=self.features)))
        score = score.reshape(n_perm, d + 1)
        phi = np.zeros(d)
        for k, order in enumerate(orders):
            for i, j in enumerate(order):
                phi[j] += score[k, i + 1] - score[k, i]
        return {f: float(v / n_perm) for f, v in zip(self.features, phi)}
